def byte_string(s):
    def word_val(s, idx):
        if s[idx] == "\0":
            return 0 
        elif idx + 1 == len(s):
            return ord(s[idx])
        elif s[idx+1] == "\0":
            return ord(s[idx])
        else:
            return (ord(s[idx]) << 8) + ord(s[idx+1])

    lOut =[]
    s = s.replace("\\0", "\0\0")
    s = s.replace("\\n", "\n")
    if s[0] == '"' and s[-1] == '"':
        s = s[1:-1]
        for idx in range(0, len(s), 2):
            lOut.append(word_val(s, idx))
    return lOut

def out(l):
    for w in l:
        print("%04X" % w, end=" ")
    print()

out(byte_string(r'""'))
out(byte_string(r'"\0"'))
out(byte_string(r'"A"'))
out(byte_string(r'"AB"'))
out(byte_string(r'"A\0"'))
out(byte_string(r'"AB\0"'))
out(byte_string(r'"ABC"'))
out(byte_string(r'"ABC\0"'))
